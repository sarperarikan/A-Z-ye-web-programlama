<?php
 
 echo $_POST['adsoyad'];
 echo "<br>";
 echo $_POST['eposta'];
 echo "<br>";
 echo $_POST['telefon'];
 echo "<br>";
 echo $_POST['cinsiyet'];
 echo "<br>";
 echo $_POST['hobiler'];
 echo "<br>";
 echo $_POST['onay'];
 echo "<br>";